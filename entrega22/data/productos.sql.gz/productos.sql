-- Adminer 4.2.5 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `productos`;
CREATE TABLE `productos` (
  `idProd` int(4) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(30) NOT NULL,
  `descripcion` varchar(80) NOT NULL,
  `codigo` varchar(10) NOT NULL,
  `foto` varchar(100) NOT NULL,
  `precio` decimal(10,2) NOT NULL,
  `stock` int(4) NOT NULL,
  PRIMARY KEY (`idProd`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `productos` (`idProd`, `nombre`, `descripcion`, `codigo`, `foto`, `precio`, `stock`) VALUES
(1,	'iPad Air 10',	'iPad Air 10 - Ultimo Modelo',	'SKU35678',	'https://cdn2.iconfinder.com/data/icons/basic-flat-icon-set/128/ipad-512.png',	556.00,	12),
(2,	'PC Gaming',	'PD 16GB, SSD 1TB, GFX, i7',	'SKU45657',	'https://cdn3.iconfinder.com/data/icons/education-science-vol-1-1/512/computer_education_information_',	655.00,	3),
(3,	'PC Oficina',	'8GB, 128 SSD, i5',	'SKU34456',	'https://cdn3.iconfinder.com/data/icons/education-science-vol-1-1/512/computer_education_information_',	366.00,	50),
(4,	'Notebook Dell',	'4GB, 1TB, i5',	'SKU76769',	'https://cdn3.iconfinder.com/data/icons/computer-and-hardware-2-1/34/123-512.png',	149.50,	92),
(5,	'otro producto',	'',	'',	'https://cdn1.iconfinder.com/data/icons/web-development-34/128/yumminky_development_28-512.png',	42341234.00,	0),
(6,	'notebook elite late 2022',	'',	'',	'https://cdn1.iconfinder.com/data/icons/web-development-34/128/yumminky_development_28-512.png',	2323223.00,	0);

-- 2022-05-07 00:18:59
